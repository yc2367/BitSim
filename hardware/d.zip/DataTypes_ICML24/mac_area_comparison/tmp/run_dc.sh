dc_shell -f run.tcl &&

rm *.syn
rm *.svf
rm *.pvl
rm *.mr
rm post-synth.*