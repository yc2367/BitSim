quartus_sh -t flow.tcl &&

rm -rf qdb
rm -rf DNI
rm *.qpf *.qsf
[ -d "tmp-clearbox" ] && rm -rf tmp-clearbox